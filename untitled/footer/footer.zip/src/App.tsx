import './App.css'
import LandingPage from "./components/common/LandingPage/LandingPage.tsx";
import Footer from "./components/common/Footer/Footer.tsx";
import DragNDropEx from "./components/practice/DragNDropEx.tsx";
import FridgeList from "./components/features/FridgeList/FridgeList.tsx";
import FridgeDetails from "./components/features/FridgeDetails/FridgeDetails.tsx";
function App() {

  return (
    <>
{/*        <LandingPage />
        <Footer />*/}
        <FridgeDetails />
        <FridgeList />
        <br />
        <DragNDropEx />
    </>
  )
}

export default App
