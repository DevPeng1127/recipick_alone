import FridgeObject from "./FridgeObject.tsx";
import {AddFridge} from "./AddFridge.tsx";

const FridgeList = () => {
    return (
        <>
            <div className={"fridge_list_wrap w-4/5 h-4/5 min-w-[500px] min-h-[900px] md:w-[900px] p-2.5 pb-5 bg-gray-400 justify-self-center"}>
                <AddFridge />
                    <FridgeObject />
                    <FridgeObject />
            </div>
        </>
    );
}
export default FridgeList;