const FridgeRefrigerator = () => {
    return (
        <>
            여기는 냉장실이세요
        </>
    );
}

export default FridgeRefrigerator;