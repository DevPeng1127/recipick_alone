const FridgeFreezer = () => {
    return (
        <>
            여기가 냉동실이구요
        </>
    );
}

export default FridgeFreezer;