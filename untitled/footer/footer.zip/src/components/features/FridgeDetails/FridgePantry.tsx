import {StorageBoxBlue, StorageBoxGreen} from "./StorageBox.tsx";
import {StorageBarBlue, StorageBarGreen} from "./StorageBar.tsx";

const FridgePantry = () => {
    return (
        <>
            <div className={"fridge_pantry_wrap max-w-full md:w-[450px] p-3 bg-amber-100 flex flex-col"}>
                <StorageBoxGreen />
                <StorageBoxBlue />
                <StorageBarBlue />
                <StorageBarGreen />
            </div>
        </>
    );
}

export default FridgePantry;