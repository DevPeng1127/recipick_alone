import {BoardContents} from "./BoardContents.tsx";
import {BoardMenus} from "./BoardMenus.tsx";

const FridgeBoards = () => {
    return (
      <>
          <div className={"fridge_boards_wrap max-w-full md:w-[450px] p-3 bg-emerald-800"}>
              <BoardMenus />
              <BoardContents />
          </div>
      </>
    );
}

export default FridgeBoards;