import {BoxOrBarBtnBlue, BoxOrBarBtnGreen} from "./FridgeButtons.tsx";
import FridgeBoards from "./FridgeBoards.tsx";
import FridgePantry from "./FridgePantry.tsx";
import FridgeFreezer from "./FridgeFreezer.tsx";
import FridgeRefrigerator from "./FridgeRefrigerator.tsx";

const FridgeDetails = () => {
    return (
        <>
            여기서 냉장고 세부 모습을 보여줍니다
            <div className={"boardAndPantry"}>
                <FridgeBoards />
                <BoxOrBarBtnBlue />
                <FridgePantry />
            </div>
            <div className="boxAndPantry">
                <BoxOrBarBtnGreen />
                <FridgeFreezer />
                <FridgeRefrigerator />
            </div>
        </>
    );
}

export default FridgeDetails;