export const BoxOrBarBtnBlue = () => {
    return (
        <>
            <button className="bg-blue-500 hover:bg-blue-400 text-xl text-blue-950 font-extrabold p-1.5 px-3 rounded-lg">BOX/BAR</button>
        </>
    );
}
export const BoxOrBarBtnGreen = () => {
    return (
        <>
            <button className="bg-emerald-400 hover:bg-emerald-300 text-xl text-blue-950 font-extrabold p-1.5 px-3 rounded-lg">BOX/BAR</button>
        </>
    );
}
